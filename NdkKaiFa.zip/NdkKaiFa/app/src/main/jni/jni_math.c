//
// Created by Administrator on 2017/5/20.
//

#include "com_fittop_ndkkaifa_MathKit.h"
//注意方法名要和.h文件里的一样
JNIEXPORT jint JNICALL Java_com_fittop_ndkkaifa_MathKit_square(JNIEnv *env, jclass cls, jint num) {
    return num * num;
}