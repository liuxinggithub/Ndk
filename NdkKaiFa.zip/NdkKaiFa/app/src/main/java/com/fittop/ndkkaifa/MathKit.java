package com.fittop.ndkkaifa;

/**
 * Created by Administrator on 2017/5/20.
 */

public class MathKit {

    public static native int square(int num);

    static {
        System.loadLibrary("native-lib");
    }
}
